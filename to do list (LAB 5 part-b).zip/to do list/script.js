const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const errorMessage = document.getElementById("errorMessage");
const taskCounter = document.getElementById("taskCounter");
const clearCompleted = document.getElementById("clearCompleted");

const filters = document.querySelectorAll(".filter");
let tasks = [];

let currentFilter = "all";
taskForm.addEventListener("submit", function(event) {

    event.preventDefault();

    const taskText = taskInput.value.trim();

    if (taskText === "") {
        errorMessage.textContent = "Please enter a task.";
        return;
    }

    const duplicate = tasks.some(function(task) {
        return task.text.toLowerCase() === taskText.toLowerCase();
    });

    if (duplicate) {
        errorMessage.textContent = "This task already exists.";
        return;
    }

    const newTask = {
        text: taskText,
        completed: false
    };

    tasks.push(newTask);

    errorMessage.textContent = "";

    taskInput.value = "";

    displayTasks();

});

function displayTasks() {

    taskList.innerHTML = "";

    tasks.forEach(function(task, index) {

        if (currentFilter === "active" && task.completed) {
            return;
        }

        if (currentFilter === "completed" && !task.completed) {
            return;
        }
        const li = document.createElement("li");

        li.classList.add("task-item");

        if (task.completed) {
            li.classList.add("completed");
        }

        li.setAttribute("data-index", index);
        const checkbox = document.createElement("input");

        checkbox.type = "checkbox";

        checkbox.classList.add("complete-checkbox");

        checkbox.checked = task.completed;
        const span = document.createElement("span");

        span.textContent = task.text;

        span.classList.add("task-text");

        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";

        deleteButton.classList.add("delete-btn");

        deleteButton.setAttribute("data-action", "delete");

        li.appendChild(checkbox);

        li.appendChild(span);

        li.appendChild(deleteButton);

        taskList.appendChild(li);

    });
    updateCounter();
}

taskList.addEventListener("click", function(event) {

    const li = event.target.closest(".task-item");

    if (!li) {
        return;
    }

    const index = li.getAttribute("data-index");

    if (event.target.dataset.action === "delete") {

        tasks.splice(index, 1);

        displayTasks();

    }

});

taskList.addEventListener("change", function(event) {

    if (event.target.classList.contains("complete-checkbox")) {

        const li = event.target.closest(".task-item");

        const index = li.getAttribute("data-index");

        tasks[index].completed = event.target.checked;

        displayTasks();

    }

});

filters.forEach(function(button) {

    button.addEventListener("click", function() {

        currentFilter = button.dataset.filter;

        filters.forEach(function(btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        displayTasks();

    });

});

function updateCounter() {

    const totalTasks = tasks.length;

    const remainingTasks = tasks.filter(function(task) {
        return !task.completed;
    }).length;

    taskCounter.textContent =
        "Total: " + totalTasks +
        " | Remaining: " + remainingTasks;

}

clearCompleted.addEventListener("click", function() {

    tasks = tasks.filter(function(task) {
        return !task.completed;
    });

    displayTasks();

});

