
import { useState } from "react";
import { useAuth } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import LoginPage from "./pages/LoginPage";
import CoursesPage from "./pages/CoursesPage";
import MyCoursesPage from "./pages/MyCoursesPage";
import ManagePage from "./pages/ManagePage";

function App() {
  const { user, logout } = useAuth();
  const [page, setPage] = useState("courses");

  const handleLogout = () => {
    logout();
    setPage("courses");
  };

  return (
    <div className="app">
      <Navbar
        user={user}
        page={page}
        setPage={setPage}
        onLogout={handleLogout}
      />

      {!user ? (
        <LoginPage setPage={setPage} />
      ) : (
        <main>
          {page === "courses" && <CoursesPage />}

          {page === "my-courses" && user.role === "student" && (
            <MyCoursesPage />
          )}

          {page === "manage" && user.role === "admin" && (
            <ManagePage />
          )}
        </main>
      )}
    </div>
  );
}

export default App;
