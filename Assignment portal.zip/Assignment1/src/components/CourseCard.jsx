
import { memo } from "react";
import Card from "./Card";
import Button from "./Button";

function CourseCard({
  course,
  actionLabel,
  onAction,
  actionDisabled = false
}) {
  return (
    <Card className="course-card">
      <div className="course-info">
        <span className="course-code">{course.code}</span>
        <h3>{course.title}</h3>

        <p>
          <strong>Instructor:</strong> {course.instructor.name}
        </p>

        <p>
          <strong>Email:</strong> {course.instructor.email}
        </p>

        <p>
          <strong>Credits:</strong> {course.credits}
        </p>
      </div>

      {actionLabel && (
        <Button
          onClick={() => onAction(course)}
          disabled={actionDisabled}
        >
          {actionLabel}
        </Button>
      )}
    </Card>
  );
}

export default memo(CourseCard);
