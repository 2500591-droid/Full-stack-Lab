
import { useState } from "react";
import Button from "./Button";

function CourseForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [code, setCode] = useState("");
  const [credits, setCredits] = useState("3");
  const [instructor, setInstructor] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const newErrors = {};

    if (!title.trim()) {
      newErrors.title = "Course title is required.";
    }

    if (!/^CS-\d{3}$/.test(code.trim())) {
      newErrors.code = "Code must follow CS-301 format.";
    }

    if (!instructor.trim()) {
      newErrors.instructor = "Instructor name is required.";
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = "Enter a valid email address.";
    }

    if (![1, 2, 3, 4].includes(Number(credits))) {
      newErrors.credits = "Credits must be between 1 and 4.";
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    onAdd({
      id: `custom-${Date.now()}`,
      title: title.trim(),
      code: code.trim().toUpperCase(),
      credits: Number(credits),
      instructor: {
        name: instructor.trim(),
        email: email.trim()
      }
    });

    setTitle("");
    setCode("");
    setCredits("3");
    setInstructor("");
    setEmail("");
    setErrors({});
  };

  return (
    <form className="admin-form" onSubmit={handleSubmit}>
      <h2>Add New Course</h2>

      <div className="form-group">
        <label>Course Title</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter course title"
        />
        {errors.title && <p className="field-error">{errors.title}</p>}
      </div>

      <div className="form-group">
        <label>Course Code</label>
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="CS-301"
        />
        {errors.code && <p className="field-error">{errors.code}</p>}
      </div>

      <div className="form-group">
        <label>Credit Hours</label>
        <select
          value={credits}
          onChange={(e) => setCredits(e.target.value)}
        >
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
        {errors.credits && <p className="field-error">{errors.credits}</p>}
      </div>

      <div className="form-group">
        <label>Instructor Name</label>
        <input
          value={instructor}
          onChange={(e) => setInstructor(e.target.value)}
          placeholder="Instructor name"
        />
        {errors.instructor && (
          <p className="field-error">{errors.instructor}</p>
        )}
      </div>

      <div className="form-group">
        <label>Instructor Email</label>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="instructor@example.com"
        />
        {errors.email && <p className="field-error">{errors.email}</p>}
      </div>

      <Button type="submit">Add Course</Button>
    </form>
  );
}

export default CourseForm;
