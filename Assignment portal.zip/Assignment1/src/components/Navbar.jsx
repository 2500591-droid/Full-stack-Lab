
import Button from "./Button";

function Navbar({ user, page, setPage, onLogout }) {
  if (!user) return null;

  return (
    <nav className="navbar">
      <div className="nav-brand">
        <h2>CoursePortal</h2>
      </div>

      <div className="nav-links">
        <Button
          variant={page === "courses" ? "primary" : "secondary"}
          onClick={() => setPage("courses")}
        >
          Courses
        </Button>

        {user.role === "student" && (
          <Button
            variant={page === "my-courses" ? "primary" : "secondary"}
            onClick={() => setPage("my-courses")}
          >
            My Courses
          </Button>
        )}

        {user.role === "admin" && (
          <Button
            variant={page === "manage" ? "primary" : "secondary"}
            onClick={() => setPage("manage")}
          >
            Manage
          </Button>
        )}

        <Button variant="danger" onClick={onLogout}>
          Logout
        </Button>
      </div>
    </nav>
  );
}

export default Navbar;
