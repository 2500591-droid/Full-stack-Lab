
import { createContext, useContext } from "react";
import useLocalStorage from "../hooks/useLocalStorage";

const AuthContext = createContext();

const users = [
  {
    username: "admin",
    password: "admin123",
    name: "Administrator",
    role: "admin"
  },
  {
    username: "student1",
    password: "student123",
    name: "Student One",
    role: "student"
  },
  {
    username: "student2",
    password: "student123",
    name: "Student Two",
    role: "student"
  }
];

export function AuthProvider({ children }) {
  const [user, setUser] = useLocalStorage("coursePortalUser", null);

  const login = (username, password) => {
    const foundUser = users.find(
      (item) =>
        item.username === username &&
        item.password === password
    );

    if (!foundUser) {
      return false;
    }

    const { password: removedPassword, ...safeUser } = foundUser;
    setUser(safeUser);

    return true;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
