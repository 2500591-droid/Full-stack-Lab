
import {
  createContext,
  useContext,
  useEffect,
  useReducer
} from "react";

const CourseContext = createContext();

const initialState = {
  enrollments: {},
  addedCourses: [],
  deletedCourseIds: []
};

function courseReducer(state, action) {
  switch (action.type) {
    case "ENROLL": {
      const currentCourses = state.enrollments[action.username] || [];

      if (currentCourses.includes(action.courseId)) {
        return state;
      }

      return {
        ...state,
        enrollments: {
          ...state.enrollments,
          [action.username]: [
            ...currentCourses,
            action.courseId
          ]
        }
      };
    }

    case "DROP": {
      const currentCourses = state.enrollments[action.username] || [];

      return {
        ...state,
        enrollments: {
          ...state.enrollments,
          [action.username]: currentCourses.filter(
            (id) => id !== action.courseId
          )
        }
      };
    }

    case "ADD_COURSE":
      return {
        ...state,
        addedCourses: [...state.addedCourses, action.course]
      };

    case "DELETE_COURSE":
      return {
        ...state,
        addedCourses: state.addedCourses.filter(
          (course) => course.id !== action.courseId
        ),
        deletedCourseIds: [
          ...state.deletedCourseIds,
          action.courseId
        ]
      };

    default:
      return state;
  }
}

export function CourseProvider({ children }) {
  const [state, dispatch] = useReducer(
    courseReducer,
    initialState,
    () => {
      try {
        const saved = localStorage.getItem("coursePortalData");
        return saved ? JSON.parse(saved) : initialState;
      } catch {
        return initialState;
      }
    }
  );

  useEffect(() => {
    localStorage.setItem("coursePortalData", JSON.stringify(state));
  }, [state]);

  return (
    <CourseContext.Provider value={{ state, dispatch }}>
      {children}
    </CourseContext.Provider>
  );
}

export function useCourses() {
  return useContext(CourseContext);
}
