
import { useState } from "react";
import { useCourses } from "../context/CourseContext";
import CourseForm from "../components/CourseForm";
import Card from "../components/Card";
import Button from "../components/Button";

function ManagePage() {
  const { state, dispatch } = useCourses();
  const [message, setMessage] = useState("");

  const handleAdd = (course) => {
    const existingCodes = [
      ...state.addedCourses
    ].map((item) => item.code.toLowerCase());

    if (existingCodes.includes(course.code.toLowerCase())) {
      setMessage("A course with this code already exists.");
      return;
    }

    dispatch({
      type: "ADD_COURSE",
      course
    });

    setMessage("Course added successfully!");
  };

  const handleDelete = (courseId) => {
    dispatch({
      type: "DELETE_COURSE",
      courseId
    });

    setMessage("Course deleted successfully!");
  };

  return (
    <section className="courses-page">
      <div className="page-heading">
        <h1>Manage Courses</h1>
        <p>Add and manage your course catalog.</p>
      </div>

      {message && <p className="status-message">{message}</p>}

      <CourseForm onAdd={handleAdd} />

      <h2 className="manage-heading">Added Courses</h2>

      <div className="course-grid">
        {state.addedCourses.length > 0 ? (
          state.addedCourses.map((course) => (
            <Card key={course.id} className="course-card">
              <span className="course-code">{course.code}</span>
              <h3>{course.title}</h3>
              <p>Instructor: {course.instructor.name}</p>
              <p>Credits: {course.credits}</p>

              <Button
                variant="danger"
                onClick={() => handleDelete(course.id)}
              >
                Delete Course
              </Button>
            </Card>
          ))
        ) : (
          <p>No admin-added courses yet.</p>
        )}
      </div>
    </section>
  );
}

export default ManagePage;
