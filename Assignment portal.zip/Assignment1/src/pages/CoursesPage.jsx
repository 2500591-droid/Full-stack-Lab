
import { useMemo, useState } from "react";
import useFetch from "../hooks/useFetch";
import { useAuth } from "../context/AuthContext";
import { useCourses } from "../context/CourseContext";
import CourseCard from "../components/CourseCard";

function CoursesPage() {
  const { data, loading, error } = useFetch("/courses.json");
  const { user } = useAuth();
  const { state, dispatch } = useCourses();

  const [search, setSearch] = useState("");
  const [credits, setCredits] = useState("all");
  const [message, setMessage] = useState("");

  const courses = useMemo(() => {
    const available = [
      ...data.filter(
        (course) => !state.deletedCourseIds.includes(course.id)
      ),
      ...state.addedCourses
    ];

    return available.filter((course) => {
      const matchesSearch =
        course.title.toLowerCase().includes(search.toLowerCase()) ||
        course.code.toLowerCase().includes(search.toLowerCase());

      const matchesCredits =
        credits === "all" || course.credits === Number(credits);

      return matchesSearch && matchesCredits;
    });
  }, [data, state, search, credits]);

  const handleEnroll = (course) => {
    const enrolled = state.enrollments[user.username] || [];

    if (enrolled.includes(course.id)) {
      setMessage("You are already enrolled in this course.");
      return;
    }

    const allCourses = [
      ...data,
      ...state.addedCourses
    ].filter(
      (item) => !state.deletedCourseIds.includes(item.id)
    );

    const currentCredits = enrolled.reduce((total, id) => {
      const found = allCourses.find((item) => item.id === id);
      return total + (found ? found.credits : 0);
    }, 0);

    if (currentCredits + course.credits > 18) {
      setMessage("You cannot exceed 18 credit hours.");
      return;
    }

    dispatch({
      type: "ENROLL",
      username: user.username,
      courseId: course.id
    });

    setMessage(`${course.title} enrolled successfully!`);
  };

  if (loading) {
    return <p className="status-message">Loading courses...</p>;
  }

  if (error) {
    return <p className="error-message">{error}</p>;
  }

  return (
    <section className="courses-page">
      <div className="page-heading">
        <h1>Available Courses</h1>
        <p>Explore and enrol in your university courses.</p>
      </div>

      <div className="course-filters">
        <input
          type="text"
          placeholder="Search by course title or code..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={credits}
          onChange={(e) => setCredits(e.target.value)}
        >
          <option value="all">All Credits</option>
          <option value="1">1 Credit</option>
          <option value="2">2 Credits</option>
          <option value="3">3 Credits</option>
          <option value="4">4 Credits</option>
        </select>
      </div>

      {message && (
        <p className="status-message">{message}</p>
      )}

      <div className="course-grid">
        {courses.map((course) => (
          <CourseCard
            key={course.id}
            course={course}
            actionLabel={
              user.role === "student" ? "Enrol Now" : null
            }
            onAction={handleEnroll}
          />
        ))}
      </div>

      {courses.length === 0 && (
        <p className="status-message">No courses found.</p>
      )}
    </section>
  );
}

export default CoursesPage;
