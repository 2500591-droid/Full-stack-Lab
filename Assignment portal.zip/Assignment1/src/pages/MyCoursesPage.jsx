
import { useMemo, useCallback } from "react";
import useFetch from "../hooks/useFetch";
import { useAuth } from "../context/AuthContext";
import { useCourses } from "../context/CourseContext";
import CourseCard from "../components/CourseCard";

function MyCoursesPage() {
  const { data, loading, error } = useFetch("/courses.json");
  const { user } = useAuth();
  const { state, dispatch } = useCourses();

  const enrolledCourses = useMemo(() => {
    const enrolledIds = state.enrollments[user.username] || [];

    const allCourses = [
      ...data,
      ...state.addedCourses
    ].filter(
      (course) => !state.deletedCourseIds.includes(course.id)
    );

    return allCourses.filter((course) =>
      enrolledIds.includes(course.id)
    );
  }, [data, state, user.username]);

  const totalCredits = useMemo(() => {
    return enrolledCourses.reduce(
      (total, course) => total + course.credits,
      0
    );
  }, [enrolledCourses]);

  const handleDrop = useCallback((course) => {
    dispatch({
      type: "DROP",
      username: user.username,
      courseId: course.id
    });
  }, [dispatch, user.username]);

  if (loading) {
    return <p className="status-message">Loading your courses...</p>;
  }

  if (error) {
    return <p className="error-message">{error}</p>;
  }

  return (
    <section className="courses-page">
      <div className="page-heading">
        <h1>My Courses</h1>
        <p>Manage your enrolled courses.</p>
      </div>

      <div className="credits-summary">
        <h2>{totalCredits} / 18</h2>
        <p>Total Credit Hours</p>
      </div>

      {enrolledCourses.length > 0 ? (
        <div className="course-grid">
          {enrolledCourses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              actionLabel="Drop Course"
              onAction={handleDrop}
            />
          ))}
        </div>
      ) : (
        <p className="status-message">
          You have not enrolled in any courses yet.
        </p>
      )}
    </section>
  );
}

export default MyCoursesPage;

