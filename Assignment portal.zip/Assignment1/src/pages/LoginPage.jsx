
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import Button from "../components/Button";
import Card from "../components/Card";

function LoginPage({ setPage }) {
  const { login } = useAuth();

  const usernameRef = useRef(null);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    document.title = "Login | CoursePortal";
    usernameRef.current?.focus();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password.");
      return;
    }

    const success = login(username, password);

    if (success) {
      setPage("courses");
    } else {
      setError("Invalid username or password.");
      setPassword("");
    }
  };

  return (
    <div className="login-page">
      <Card className="login-card">
        <div className="login-heading">
          <h1>Welcome Back</h1>
          <p>Login to your Student Course Portal</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Username</label>

            <input
              ref={usernameRef}
              id="username"
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>

            <input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {error && (
            <p className="error-message">{error}</p>
          )}

          <Button type="submit" variant="primary">
            Login
          </Button>
        </form>

        <div className="login-hint">
          <p>Admin: admin / admin123</p>
          <p>Student: student1 / student123</p>
        </div>
      </Card>
    </div>
  );
}

export default LoginPage;
