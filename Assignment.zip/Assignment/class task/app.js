function calculateGrade() {

    const name = document.getElementById("name").value;
    const marks = Number(document.getElementById("marks").value);
    const result = document.getElementById("result");

    if (name === "" || marks < 0 || marks > 100 || isNaN(marks)) {

        result.textContent = "Please enter a valid name and marks.";
        result.style.color = "red";

        return;
    }

    let grade;

    if (marks >= 85) {
        grade = "A";
    }
    else if (marks >= 70) {
        grade = "B";
    }
    else if (marks >= 50) {
        grade = "C";
    }
    else {
        grade = "F";
    }

    result.textContent = `${name} scored ${marks} → Grade ${grade}`;

    if (grade === "F") {
        result.style.color = "red";
    }
    else {
        result.style.color = "green";
    }
}

const calcButton = document.getElementById("calcBtn");

calcButton.addEventListener("click", calculateGrade);