
const students = [
    {
        name: "Ayesha",
        rollNo: "FSWD-01",
        marks: 88
    },

    {
        name: "Ali",
        rollNo: "FSWD-02",
        marks: 74
    },

    {
        name: "Sara",
        rollNo: "FSWD-03",
        marks: 91
    },

    {
        name: "Ahmed",
        rollNo: "FSWD-04",
        marks: 63
    },

    {
        name: "Hina",
        rollNo: "FSWD-05",
        marks: 48
    }
];
function getGrade(marks) {

    if (marks >= 85) {
        return "A";
    }
    else if (marks >= 70) {
        return "B";
    }
    else if (marks >= 50) {
        return "C";
    }
    else {
        return "F";
    }
}

const studentTable = document.getElementById("studentTable");

let totalMarks = 0;
let topStudent = students[0];


for (let i = 0; i < students.length; i++) {

    const student = students[i];

    const row = document.createElement("tr");

    row.innerHTML = `
        <td>${student.name}</td>
        <td>${student.rollNo}</td>
        <td>${student.marks}</td>
        <td>${getGrade(student.marks)}</td>
    `;

    studentTable.appendChild(row);

    totalMarks = totalMarks + student.marks;

    if (student.marks > topStudent.marks) {
        topStudent = student;
    }
}

const average = totalMarks / students.length;

document.getElementById("average").textContent =
    `Class Average: ${average.toFixed(1)}`;

document.getElementById("topScorer").textContent =
    `Top Scorer: ${topStudent.name}`;