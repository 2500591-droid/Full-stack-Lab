
function celsiusToFahrenheit(c) {
    return (c * 9 / 5) + 32;
}

const fahrenheitToCelsius = (f) => {
    return (f - 32) * 5 / 9;
};

const temperatureInput = document.getElementById("temperature");
const result = document.getElementById("result");

document.getElementById("toFahrenheit").addEventListener("click", function () {

    const value = Number(temperatureInput.value);

    if (temperatureInput.value === "" || isNaN(value)) {
        result.textContent = "Please enter a valid number.";
        result.style.color = "red";
        return;
    }

    const answer = celsiusToFahrenheit(value);

    result.textContent = `${value} °C = ${answer.toFixed(1)} °F`;
    result.style.color = "green";
});

document.getElementById("toCelsius").addEventListener("click", function () {

    const value = Number(temperatureInput.value);

    if (temperatureInput.value === "" || isNaN(value)) {
        result.textContent = "Please enter a valid number.";
        result.style.color = "red";
        return;
    }

    const answer = fahrenheitToCelsius(value);

    result.textContent = `${value} °F = ${answer.toFixed(1)} °C`;
    result.style.color = "green";
});